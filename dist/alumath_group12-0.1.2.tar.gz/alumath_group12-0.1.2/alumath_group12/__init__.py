"""
Module for matrices multiplication
Import the matrices multiplication function from the core module
"""
from .core import multiply_matrices